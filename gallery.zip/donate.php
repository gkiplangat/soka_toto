<!--Include Header -->
<?php include "includes/header.php" ?>

<!--Include Page Start -->
<?php include "includes/page_header.php" ?>

<!--Include Donate Section -->
<?php include "includes/donate.php" ?>
        
<!--Include Footer Section -->
<?php include "includes/footer.php" ?>