<!--Include Header Section -->
<?php 
include "includes/header.php"
?>
<!-- Page Header Start -->
<div class="container-fluid page-header wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center">
        <h1 class="display-4 text-dark animated slideInDown mb-4">Our Events</h1>
    </div>
</div>
<!-- Page Header End -->
<!--Include 404 error -->
<?php include "includes/get_news.php" ?>

<!--Include Footer Section -->
<?php 
include "includes/footer.php"
?>