<!-- Donate Start -->
<div>
      <div class="container py-5">
        <div class="row g-5 align-items-center">
          <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
            <div
              class="d-inline-block rounded-pill bg-secondary text-primary py-1 px-3 mb-3"
            >
              Support Now
            </div>
            <h1 class="display-6 mb-5">
              Thanks For Your Continued Support
            </h1>
            <p class="mb-3">
            Dear Revivalist,  
            Your support plays a vital role in reaching out to souls. We deeply value and warmly welcome your contribution.
            </p>

            <p class=" text-dark mt-2"><strong>Proverbs 11:25 The generous will prosper; those who refresh others will themselves be refreshed</strong></p>

          </div>
          <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
            <div class="h-100 bg-secondary p-5">
              <form>
                <div class="row g-3 text-center">
                  <h3>Partner With Us</h3>
                  <h5 >MPESA</h5>
                  <p>Paybill Number: 597085 <br>Account Number: Purpose of Giving (i.e Gideon-Missions)</p>
                  <h5>BANK</h5>
                  <p>Account Name: Feed My Lambs Youth Ministry <br> Account Number: 01128306657900 <br> Bank Name : Co-operative Bank <br>Branch: AgaKhan Walk <br>Swift Code: KCOOKENA
                  </p>

                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Donate End -->