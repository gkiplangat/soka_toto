<!--Include Header Section -->
<?php 
include "includes/header.php"
?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center">
            <h1 class="display-4 text-white animated slideInDown mb-4">Gallery</h1>
        </div>
    </div>
    <!-- Page Header End -->

<!--Include 404 error -->
<?php include "includes/get_gallery.php" ?>

<!--Include Footer Section -->
<?php 
include "includes/footer.php"
?>