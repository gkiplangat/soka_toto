<!--Include Header Section -->
<?php include 'includes/header.php' ?>

<h1>FLY_M Meetings Page</h1>

<!--Include Footer Section-->
<?php include 'includes/footer.php' ?>